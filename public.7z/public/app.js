angular.module('app', ['ngRoute'])
    .config(['$locationProvider', function ($locationProvider) {
        $locationProvider.hashPrefix('');
    }])
    .config(function ($routeProvider) { //Створюєм адреси
        $routeProvider
            .when('/', {
                templateUrl: './template/homePageDirective.html'
            })
            .otherwise({
                redirectTo: '/'
            });

    })
    .controller('mainCtrl', function () {
        
    })
    .directive('homePage', function () {
        return {
            restrict: 'E',
            templateUrl: './template/homePageDirective.html',
            replace: true,
            controller: HomePageController,
            controllerAs: 'homePageCtrl',
            bindToController: true,
            scope: {
                a: '@'
            }
        }
    });

function HomePageController($scope) {
    vm = this;
    $scope.a = '1111';
    vm.a = '2222';
}
